#!/usr/bin/env python3
"""
Bot Telegram para gerenciar contas Free Fire
Funcionalidades:
- /add <token> - Adicionar conta Free Fire
- /status - Ver status das contas
- /start_auto <id> - Iniciar automação
- /stop_auto <id> - Parar automação
- /security <id> - Verificar segurança
- /list - Listar contas
"""

import asyncio
import logging
import requests
import json
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# Configuração de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configurações
BOT_TOKEN = "7862652022:AAG22CFcGrGavgTnMKbWjkq_qAqzVHVKjPo"
API_BASE_URL = "http://localhost:5001/api"

class FreeFireBotAPI:
    """Cliente para comunicação com a API Flask"""
    
    @staticmethod
    def add_account(user_id, username, token):
        """Adiciona nova conta via API"""
        try:
            response = requests.post(f"{API_BASE_URL}/accounts", json={
                "user_id": str(user_id),
                "username": username,
                "token": token
            }, timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def get_user_accounts(user_id):
        """Obtém contas do usuário"""
        try:
            response = requests.get(f"{API_BASE_URL}/accounts/{user_id}", timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def get_user_summary(user_id):
        """Obtém resumo das contas do usuário"""
        try:
            response = requests.get(f"{API_BASE_URL}/accounts/{user_id}/summary", timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def start_automation(account_id, automation_type="both"):
        """Inicia automação para uma conta"""
        try:
            response = requests.post(f"{API_BASE_URL}/accounts/{account_id}/start-automation", json={
                "automation_type": automation_type,
                "duration_hours": 24
            }, timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def stop_automation(account_id):
        """Para automação de uma conta"""
        try:
            response = requests.post(f"{API_BASE_URL}/accounts/{account_id}/stop-automation", timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def security_check(account_id):
        """Verifica segurança de uma conta"""
        try:
            response = requests.post(f"{API_BASE_URL}/accounts/{account_id}/security-check", timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500
    
    @staticmethod
    def force_disconnect(account_id):
        """Força desconexão de outras sessões"""
        try:
            response = requests.post(f"{API_BASE_URL}/accounts/{account_id}/force-disconnect", timeout=10)
            return response.json(), response.status_code
        except Exception as e:
            return {"error": f"Erro de conexão: {str(e)}"}, 500

# Comandos do Bot
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /start - Mensagem de boas-vindas"""
    welcome_message = """
🎮 **Bot Free Fire UP System** 🎮

Bem-vindo ao sistema de automação Free Fire!

**Comandos disponíveis:**
• `/add <token_ou_url>` - Adicionar conta Free Fire
• `/status` - Ver status das suas contas
• `/list` - Listar todas as suas contas
• `/start_auto <id>` - Iniciar automação
• `/stop_auto <id>` - Parar automação
• `/security <id>` - Verificar segurança da conta

**Como adicionar conta:**
Você pode usar o comando `/add` de duas formas:

1️⃣ **URL completa do Garena:**
`/add https://reward.ff.garena.com/pt?access_token=306BF4EE4DBB...`

2️⃣ **Apenas o token:**
`/add 306BF4EE4DBB9327CF90E9FAE1E37E6ADCA45761...`

**Funcionalidades:**
✅ Manter contas online automaticamente
✅ Ganhar XP e subir de nível
✅ Proteção contra uso em outros sistemas
✅ Monitoramento de segurança 24/7
✅ Desconexão automática de outros bots

Para começar, use `/add` com sua URL ou token do Free Fire!
    """
    await update.message.reply_text(welcome_message, parse_mode='Markdown')

async def add_account(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /add <token> - Adicionar conta Free Fire"""
    user_id = update.effective_user.id
    username = update.effective_user.username or "Usuário"
    
    if not context.args:
        await update.message.reply_text(
            "❌ **Uso incorreto!**\n\n"
            "**Use uma das formas abaixo:**\n\n"
            "1️⃣ **URL completa do Garena:**\n"
            "`/add https://reward.ff.garena.com/pt?access_token=306BF4EE4DBB...`\n\n"
            "2️⃣ **Apenas o token:**\n"
            "`/add 306BF4EE4DBB9327CF90E9FAE1E37E6ADCA45761...`\n\n"
            "💡 **Dica:** Copie a URL completa do Free Fire Garena!",
            parse_mode='Markdown'
        )
        return
    
    token_input = ' '.join(context.args).strip()
    
    # Validação básica
    if len(token_input) < 50:
        await update.message.reply_text(
            "❌ **Token/URL muito curto!**\n\n"
            "✅ **Formato correto:**\n"
            "• URL: `https://reward.ff.garena.com/pt?access_token=...`\n"
            "• Token: Mínimo 50 caracteres hexadecimais\n\n"
            "💡 Certifique-se de copiar a URL completa do Garena!",
            parse_mode='Markdown'
        )
        return
    
    # Enviar mensagem de processamento
    processing_msg = await update.message.reply_text("⏳ Processando sua conta...")
    
    # Adicionar conta via API
    result, status_code = FreeFireBotAPI.add_account(user_id, username, token_input)
    
    if status_code == 201:
        # Sucesso - iniciar automação automaticamente
        account_id = result['account']['id']
        auto_result, auto_status = FreeFireBotAPI.start_automation(account_id)
        
        success_message = f"""
✅ **Conta adicionada com sucesso!**

🆔 **ID da Conta:** {account_id}
🎮 **Status:** Online e ativa
🤖 **Automação:** Iniciada automaticamente
📈 **Nível:** {result['account']['current_level']}
⚡ **XP Hoje:** {result['account']['xp_today']}

Sua conta agora está sendo mantida online e ganhando XP automaticamente!
        """
        
        # Criar teclado inline para ações rápidas
        keyboard = [
            [InlineKeyboardButton("📊 Ver Status", callback_data=f"status_{account_id}")],
            [InlineKeyboardButton("🔒 Verificar Segurança", callback_data=f"security_{account_id}")],
            [InlineKeyboardButton("⏹️ Parar Automação", callback_data=f"stop_{account_id}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await processing_msg.edit_text(success_message, parse_mode='Markdown', reply_markup=reply_markup)
        
    else:
        # Erro
        error_message = f"❌ **Erro ao adicionar conta:**\n\n{result.get('error', 'Erro desconhecido')}"
        await processing_msg.edit_text(error_message, parse_mode='Markdown')

async def list_accounts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /list - Listar contas do usuário"""
    user_id = update.effective_user.id
    
    result, status_code = FreeFireBotAPI.get_user_accounts(user_id)
    
    if status_code != 200:
        await update.message.reply_text(
            f"❌ **Erro ao buscar contas:**\n\n{result.get('error', 'Erro desconhecido')}",
            parse_mode='Markdown'
        )
        return
    
    accounts = result.get('accounts', [])
    
    if not accounts:
        await update.message.reply_text(
            "📝 **Nenhuma conta encontrada!**\n\n"
            "Use `/add <token>` para adicionar sua primeira conta.",
            parse_mode='Markdown'
        )
        return
    
    message = "📋 **Suas Contas Free Fire:**\n\n"
    
    for account in accounts:
        status_emoji = "🟢" if account['is_online'] else "🔴"
        auto_emoji = "🤖" if account['automation_active'] else "⏸️"
        
        message += f"""
{status_emoji} **Conta #{account['id']}**
├ 📈 Nível: {account['current_level']}
├ ⚡ XP Total: {account['total_xp']:,}
├ 📊 XP Hoje: {account['xp_today']:,}
├ {auto_emoji} Automação: {'Ativa' if account['automation_active'] else 'Inativa'}
└ 🕐 Última atividade: {account['last_activity'][:16] if account['last_activity'] else 'N/A'}

"""
    
    # Criar teclado para ações rápidas
    keyboard = []
    for account in accounts[:5]:  # Máximo 5 contas no teclado
        keyboard.append([
            InlineKeyboardButton(f"📊 Conta #{account['id']}", callback_data=f"status_{account['id']}")
        ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, parse_mode='Markdown', reply_markup=reply_markup)

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /status - Ver resumo das contas"""
    user_id = update.effective_user.id
    
    result, status_code = FreeFireBotAPI.get_user_summary(user_id)
    
    if status_code != 200:
        await update.message.reply_text(
            f"❌ **Erro ao buscar status:**\n\n{result.get('error', 'Erro desconhecido')}",
            parse_mode='Markdown'
        )
        return
    
    summary = result.get('summary', {})
    
    message = f"""
📊 **Resumo das Suas Contas**

📱 **Total de Contas:** {summary.get('total_accounts', 0)}
🟢 **Contas Online:** {summary.get('online_accounts', 0)}
🤖 **Automações Ativas:** {summary.get('active_automations', 0)}
⚡ **XP Total Hoje:** {summary.get('total_xp_today', 0):,}

🕐 **Atualizado:** {datetime.now().strftime('%H:%M:%S')}
    """
    
    keyboard = [
        [InlineKeyboardButton("🔄 Atualizar", callback_data="refresh_status")],
        [InlineKeyboardButton("📋 Ver Detalhes", callback_data="list_accounts")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(message, parse_mode='Markdown', reply_markup=reply_markup)

async def start_automation_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /start_auto <id> - Iniciar automação"""
    if not context.args:
        await update.message.reply_text(
            "❌ **Uso incorreto!**\n\n"
            "Use: `/start_auto <id_da_conta>`\n"
            "Exemplo: `/start_auto 1`",
            parse_mode='Markdown'
        )
        return
    
    try:
        account_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ **ID da conta deve ser um número!**", parse_mode='Markdown')
        return
    
    result, status_code = FreeFireBotAPI.start_automation(account_id)
    
    if status_code == 200:
        await update.message.reply_text(
            f"✅ **Automação iniciada!**\n\n"
            f"🆔 Conta: #{account_id}\n"
            f"🤖 Status: Ativa\n"
            f"📈 Tipo: {result.get('automation_type', 'both')}",
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            f"❌ **Erro ao iniciar automação:**\n\n{result.get('error', 'Erro desconhecido')}",
            parse_mode='Markdown'
        )

async def stop_automation_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /stop_auto <id> - Parar automação"""
    if not context.args:
        await update.message.reply_text(
            "❌ **Uso incorreto!**\n\n"
            "Use: `/stop_auto <id_da_conta>`\n"
            "Exemplo: `/stop_auto 1`",
            parse_mode='Markdown'
        )
        return
    
    try:
        account_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ **ID da conta deve ser um número!**", parse_mode='Markdown')
        return
    
    result, status_code = FreeFireBotAPI.stop_automation(account_id)
    
    if status_code == 200:
        await update.message.reply_text(
            f"⏹️ **Automação parada!**\n\n"
            f"🆔 Conta: #{account_id}\n"
            f"🤖 Status: Inativa",
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            f"❌ **Erro ao parar automação:**\n\n{result.get('error', 'Erro desconhecido')}",
            parse_mode='Markdown'
        )

async def security_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /security <id> - Verificar segurança"""
    if not context.args:
        await update.message.reply_text(
            "❌ **Uso incorreto!**\n\n"
            "Use: `/security <id_da_conta>`\n"
            "Exemplo: `/security 1`",
            parse_mode='Markdown'
        )
        return
    
    try:
        account_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ **ID da conta deve ser um número!**", parse_mode='Markdown')
        return
    
    # Verificar segurança
    result, status_code = FreeFireBotAPI.security_check(account_id)
    
    if status_code != 200:
        await update.message.reply_text(
            f"❌ **Erro na verificação:**\n\n{result.get('error', 'Erro desconhecido')}",
            parse_mode='Markdown'
        )
        return
    
    security_status = result.get('security_status', {})
    conflict_detected = security_status.get('conflict_detected', False)
    
    if conflict_detected:
        message = f"""
🚨 **CONFLITO DETECTADO!**

🆔 **Conta:** #{account_id}
⚠️ **Status:** Token sendo usado em outro sistema
🔧 **Ação:** {security_status.get('action_taken', 'Desconexão forçada')}
🕐 **Timestamp:** {security_status.get('timestamp', 'N/A')[:16]}

✅ **Outras sessões foram desconectadas automaticamente!**
        """
        
        keyboard = [
            [InlineKeyboardButton("🔄 Verificar Novamente", callback_data=f"security_{account_id}")],
            [InlineKeyboardButton("🚀 Reiniciar Automação", callback_data=f"start_{account_id}")]
        ]
    else:
        message = f"""
✅ **CONTA SEGURA**

🆔 **Conta:** #{account_id}
🔒 **Status:** {security_status.get('status', 'Seguro')}
🕐 **Verificado:** {security_status.get('timestamp', 'N/A')[:16]}

Nenhum conflito detectado. Sua conta está protegida!
        """
        
        keyboard = [
            [InlineKeyboardButton("🔄 Verificar Novamente", callback_data=f"security_{account_id}")],
            [InlineKeyboardButton("📊 Ver Status", callback_data=f"status_{account_id}")]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, parse_mode='Markdown', reply_markup=reply_markup)

# Handlers para botões inline
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handler para botões inline"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith("status_"):
        account_id = int(data.split("_")[1])
        # Implementar visualização de status detalhado
        await query.edit_message_text(
            f"📊 **Status da Conta #{account_id}**\n\n⏳ Carregando informações...",
            parse_mode='Markdown'
        )
    
    elif data.startswith("security_"):
        account_id = int(data.split("_")[1])
        # Executar verificação de segurança
        result, status_code = FreeFireBotAPI.security_check(account_id)
        
        if status_code == 200:
            security_status = result.get('security_status', {})
            conflict = security_status.get('conflict_detected', False)
            
            message = f"""
{'🚨 CONFLITO DETECTADO!' if conflict else '✅ CONTA SEGURA'}

🆔 **Conta:** #{account_id}
🔒 **Status:** {security_status.get('status', 'Verificando...')}
🕐 **Verificado:** {datetime.now().strftime('%H:%M:%S')}
            """
        else:
            message = f"❌ **Erro na verificação:** {result.get('error', 'Erro desconhecido')}"
        
        await query.edit_message_text(message, parse_mode='Markdown')
    
    elif data.startswith("start_"):
        account_id = int(data.split("_")[1])
        result, status_code = FreeFireBotAPI.start_automation(account_id)
        
        if status_code == 200:
            message = f"✅ **Automação iniciada para conta #{account_id}!**"
        else:
            message = f"❌ **Erro:** {result.get('error', 'Erro desconhecido')}"
        
        await query.edit_message_text(message, parse_mode='Markdown')
    
    elif data.startswith("stop_"):
        account_id = int(data.split("_")[1])
        result, status_code = FreeFireBotAPI.stop_automation(account_id)
        
        if status_code == 200:
            message = f"⏹️ **Automação parada para conta #{account_id}!**"
        else:
            message = f"❌ **Erro:** {result.get('error', 'Erro desconhecido')}"
        
        await query.edit_message_text(message, parse_mode='Markdown')

def main() -> None:
    """Função principal do bot"""
    # Criar aplicação
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Registrar handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("add", add_account))
    application.add_handler(CommandHandler("list", list_accounts))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("start_auto", start_automation_command))
    application.add_handler(CommandHandler("stop_auto", stop_automation_command))
    application.add_handler(CommandHandler("security", security_command))
    application.add_handler(CallbackQueryHandler(button_handler))
    
    # Iniciar bot
    print("🤖 Bot Free Fire UP System iniciado!")
    print(f"🔗 API Base URL: {API_BASE_URL}")
    print("📱 Aguardando comandos...")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()

