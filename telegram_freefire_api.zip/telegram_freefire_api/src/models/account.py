from src.models.user import db
from datetime import datetime
from cryptography.fernet import Fernet
import os

# Chave para criptografia dos tokens (em produção, usar variável de ambiente)
ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY', Fernet.generate_key())
cipher_suite = Fernet(ENCRYPTION_KEY)

class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), nullable=False)  # Telegram User ID
    username = db.Column(db.String(100), nullable=True)  # Telegram Username
    token_encrypted = db.Column(db.Text, nullable=False)  # Free Fire Token criptografado
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = db.Column(db.String(20), default='active')  # active/inactive
    
    # Campos para automação Free Fire
    current_level = db.Column(db.Integer, default=1)
    total_xp = db.Column(db.Integer, default=0)
    xp_today = db.Column(db.Integer, default=0)
    is_online = db.Column(db.Boolean, default=False)
    automation_active = db.Column(db.Boolean, default=False)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    automation_type = db.Column(db.String(50), default='both')  # xp_farming, stay_online, both

    def __repr__(self):
        return f'<Account {self.id} - User {self.user_id}>'

    def set_token(self, token):
        """Criptografa e armazena o token"""
        self.token_encrypted = cipher_suite.encrypt(token.encode()).decode()

    def get_token(self):
        """Descriptografa e retorna o token"""
        return cipher_suite.decrypt(self.token_encrypted.encode()).decode()

    def to_dict(self, include_token=False):
        """Converte para dicionário, opcionalmente incluindo o token"""
        result = {
            'id': self.id,
            'user_id': self.user_id,
            'username': self.username,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'status': self.status,
            'current_level': self.current_level,
            'total_xp': self.total_xp,
            'xp_today': self.xp_today,
            'is_online': self.is_online,
            'automation_active': self.automation_active,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None,
            'automation_type': self.automation_type
        }
        
        if include_token:
            result['token'] = self.get_token()
            
        return result

    @staticmethod
    def get_user_accounts(user_id):
        """Retorna todas as contas de um usuário"""
        return Account.query.filter_by(user_id=user_id, status='active').all()

    @staticmethod
    def count_user_accounts(user_id):
        """Conta quantas contas ativas um usuário possui"""
        return Account.query.filter_by(user_id=user_id, status='active').count()



    # Métodos de segurança
    def check_token_conflict(self):
        """Verifica se há conflito de token (uso em outro sistema)"""
        # Simular verificação de conflito
        # Em implementação real, verificaria se o token está sendo usado em outro lugar
        import random
        return random.choice([True, False])  # Simula detecção de conflito
    
    def force_disconnect_conflicting_sessions(self):
        """Força desconexão de sessões conflitantes"""
        if self.check_token_conflict():
            # Simular ação de desconexão forçada
            self.last_activity = datetime.utcnow()
            return True
        return False
    
    def update_security_status(self):
        """Atualiza status de segurança da conta"""
        conflict_detected = self.check_token_conflict()
        if conflict_detected:
            # Forçar desconexão de outros sistemas
            self.force_disconnect_conflicting_sessions()
            return {
                'conflict_detected': True,
                'action_taken': 'Sessões conflitantes desconectadas',
                'timestamp': datetime.utcnow().isoformat()
            }
        return {
            'conflict_detected': False,
            'status': 'Seguro',
            'timestamp': datetime.utcnow().isoformat()
        }

class SecurityLog(db.Model):
    """Log de eventos de segurança"""
    id = db.Column(db.Integer, primary_key=True)
    account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    event_type = db.Column(db.String(50), nullable=False)  # conflict_detected, forced_disconnect, etc
    description = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SecurityLog {self.id} - {self.event_type}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'account_id': self.account_id,
            'event_type': self.event_type,
            'description': self.description,
            'ip_address': self.ip_address,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

