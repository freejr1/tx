from flask import Blueprint, jsonify, request
from src.models.user import db
from src.models.account import Account
from datetime import datetime
import re

account_bp = Blueprint('account', __name__)

# Limite máximo de contas por usuário
MAX_ACCOUNTS_PER_USER = 5

def validate_freefire_token(token_input):
    """Valida e extrai token Free Fire de URL ou token direto"""
    import re
    from urllib.parse import urlparse, parse_qs
    
    # Se for uma URL do Garena
    if token_input.startswith('http'):
        try:
            parsed_url = urlparse(token_input)
            
            # Verificar se é URL do Garena
            if 'garena.com' not in parsed_url.netloc:
                return None, "URL deve ser do domínio garena.com"
            
            # Extrair access_token da URL
            query_params = parse_qs(parsed_url.query)
            if 'access_token' not in query_params:
                return None, "access_token não encontrado na URL"
            
            access_token = query_params['access_token'][0]
            
            # Validar formato do token
            if len(access_token) < 50:
                return None, "Token muito curto"
            
            # Verificar se contém apenas caracteres válidos (hex)
            if not re.match(r'^[A-F0-9]+$', access_token):
                return None, "Token contém caracteres inválidos"
            
            return access_token, None
            
        except Exception as e:
            return None, f"Erro ao processar URL: {str(e)}"
    
    # Se for token direto
    else:
        token = token_input.strip()
        
        # Validar formato do token direto
        if len(token) < 50:
            return None, "Token muito curto"
        
        if not re.match(r'^[A-F0-9]+$', token):
            return None, "Token contém caracteres inválidos"
        
        return token, None

@account_bp.route('/accounts', methods=['POST'])
def create_account():
    """Adiciona nova conta Free Fire"""
    try:
        data = request.json
        
        # Validação dos dados obrigatórios
        if not data or 'token' not in data or 'user_id' not in data:
            return jsonify({'error': 'Token e user_id são obrigatórios'}), 400
        
        token_input = data['token'].strip()
        user_id = str(data['user_id']).strip()
        username = data.get('username', '').strip()
        
        # Validação e extração do token
        token, validation_error = validate_freefire_token(token_input)
        if validation_error:
            return jsonify({'error': f'Token inválido: {validation_error}'}), 400
        
        # Verificar limite de contas por usuário
        current_count = Account.count_user_accounts(user_id)
        if current_count >= MAX_ACCOUNTS_PER_USER:
            return jsonify({
                'error': f'Limite máximo de {MAX_ACCOUNTS_PER_USER} contas por usuário atingido'
            }), 400
        
        # Verificar se o token já existe para este usuário
        existing_accounts = Account.get_user_accounts(user_id)
        for acc in existing_accounts:
            if acc.get_token() == token:
                return jsonify({'error': 'Este token já está cadastrado para sua conta'}), 409
        
        # Criar nova conta
        account = Account(
            user_id=user_id,
            username=username
        )
        account.set_token(token)
        
        db.session.add(account)
        db.session.commit()
        
        return jsonify({
            'message': 'Conta Free Fire adicionada com sucesso',
            'account': account.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@account_bp.route('/accounts/<user_id>', methods=['GET'])
def get_user_accounts(user_id):
    """Lista contas de um usuário"""
    try:
        accounts = Account.get_user_accounts(user_id)
        return jsonify({
            'user_id': user_id,
            'total_accounts': len(accounts),
            'accounts': [account.to_dict() for account in accounts]
        })
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar contas: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>', methods=['GET'])
def get_account(account_id):
    """Obtém detalhes de uma conta específica"""
    try:
        account = Account.query.get_or_404(account_id)
        return jsonify(account.to_dict(include_token=True))
    except Exception as e:
        return jsonify({'error': f'Conta não encontrada: {str(e)}'}), 404

@account_bp.route('/accounts/<int:account_id>', methods=['DELETE'])
def delete_account(account_id):
    """Remove uma conta (marca como inativa)"""
    try:
        account = Account.query.get_or_404(account_id)
        account.status = 'inactive'
        db.session.commit()
        
        return jsonify({
            'message': 'Conta removida com sucesso',
            'account_id': account_id
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro ao remover conta: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>/status', methods=['PUT'])
def update_account_status(account_id):
    """Atualiza status de uma conta"""
    try:
        account = Account.query.get_or_404(account_id)
        data = request.json
        
        if 'status' not in data:
            return jsonify({'error': 'Status é obrigatório'}), 400
        
        new_status = data['status']
        if new_status not in ['active', 'inactive']:
            return jsonify({'error': 'Status deve ser active ou inactive'}), 400
        
        account.status = new_status
        db.session.commit()
        
        return jsonify({
            'message': 'Status atualizado com sucesso',
            'account': account.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro ao atualizar status: {str(e)}'}), 500

@account_bp.route('/health', methods=['GET'])
def health_check():
    """Endpoint de verificação de saúde da API"""
    return jsonify({
        'status': 'healthy',
        'service': 'Telegram Free Fire API',
        'version': '1.0.0'
    })



@account_bp.route('/accounts/<int:account_id>/start-automation', methods=['POST'])
def start_automation(account_id):
    """Inicia automação para uma conta"""
    try:
        account = Account.query.get_or_404(account_id)
        data = request.json or {}
        
        automation_type = data.get('automation_type', 'both')
        duration_hours = data.get('duration_hours', 24)
        
        if automation_type not in ['xp_farming', 'stay_online', 'both']:
            return jsonify({'error': 'Tipo de automação inválido'}), 400
        
        # Atualizar conta para iniciar automação
        account.automation_active = True
        account.automation_type = automation_type
        account.is_online = True
        account.last_activity = datetime.utcnow()
        
        db.session.commit()
        
        # Aqui seria iniciado o processo de automação real
        # Por enquanto, apenas simulamos
        
        return jsonify({
            'message': f'Automação iniciada para conta {account_id}',
            'automation_type': automation_type,
            'duration_hours': duration_hours,
            'account': account.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro ao iniciar automação: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>/stop-automation', methods=['POST'])
def stop_automation(account_id):
    """Para automação de uma conta"""
    try:
        account = Account.query.get_or_404(account_id)
        
        account.automation_active = False
        account.is_online = False
        account.last_activity = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': f'Automação parada para conta {account_id}',
            'account': account.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro ao parar automação: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>/status', methods=['GET'])
def get_account_status(account_id):
    """Verifica status detalhado de automação de uma conta"""
    try:
        account = Account.query.get_or_404(account_id)
        
        # Simular ganho de XP se automação estiver ativa
        if account.automation_active:
            # Simular XP ganho baseado no tempo
            import random
            xp_gain = random.randint(10, 50)
            account.xp_today += xp_gain
            account.total_xp += xp_gain
            
            # Calcular nível baseado no XP total (exemplo: 1000 XP por nível)
            new_level = (account.total_xp // 1000) + 1
            if new_level > account.current_level:
                account.current_level = new_level
            
            account.last_activity = datetime.utcnow()
            db.session.commit()
        
        return jsonify({
            'account_id': account.id,
            'is_online': account.is_online,
            'automation_active': account.automation_active,
            'current_level': account.current_level,
            'total_xp': account.total_xp,
            'xp_today': account.xp_today,
            'last_activity': account.last_activity.isoformat() if account.last_activity else None,
            'automation_type': account.automation_type
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao verificar status: {str(e)}'}), 500

@account_bp.route('/accounts/<user_id>/summary', methods=['GET'])
def get_user_summary(user_id):
    """Resumo de todas as contas de um usuário"""
    try:
        accounts = Account.get_user_accounts(user_id)
        
        total_accounts = len(accounts)
        online_accounts = sum(1 for acc in accounts if acc.is_online)
        active_automations = sum(1 for acc in accounts if acc.automation_active)
        total_xp_today = sum(acc.xp_today for acc in accounts)
        
        return jsonify({
            'user_id': user_id,
            'summary': {
                'total_accounts': total_accounts,
                'online_accounts': online_accounts,
                'active_automations': active_automations,
                'total_xp_today': total_xp_today
            },
            'accounts': [acc.to_dict() for acc in accounts]
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao gerar resumo: {str(e)}'}), 500


@account_bp.route('/accounts/<int:account_id>/security-check', methods=['POST'])
def security_check(account_id):
    """Verifica segurança da conta e detecta conflitos"""
    try:
        account = Account.query.get_or_404(account_id)
        
        # Verificar conflitos de token
        security_status = account.update_security_status()
        
        # Registrar evento de segurança
        from src.models.account import SecurityLog
        security_log = SecurityLog(
            account_id=account_id,
            event_type='security_check',
            description=f"Verificação de segurança: {security_status['status'] if not security_status['conflict_detected'] else 'Conflito detectado'}",
            ip_address=request.remote_addr
        )
        db.session.add(security_log)
        
        if security_status['conflict_detected']:
            # Se conflito detectado, parar automação temporariamente
            account.automation_active = False
            account.is_online = False
            
            # Registrar evento de desconexão forçada
            disconnect_log = SecurityLog(
                account_id=account_id,
                event_type='forced_disconnect',
                description='Desconexão forçada devido a conflito de token',
                ip_address=request.remote_addr
            )
            db.session.add(disconnect_log)
        
        db.session.commit()
        
        return jsonify({
            'account_id': account_id,
            'security_status': security_status,
            'account_status': account.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro na verificação de segurança: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>/force-disconnect', methods=['POST'])
def force_disconnect_others(account_id):
    """Força desconexão de outras sessões usando o mesmo token"""
    try:
        account = Account.query.get_or_404(account_id)
        
        # Forçar desconexão de sessões conflitantes
        disconnect_result = account.force_disconnect_conflicting_sessions()
        
        # Registrar evento
        from src.models.account import SecurityLog
        security_log = SecurityLog(
            account_id=account_id,
            event_type='manual_disconnect',
            description='Desconexão manual de sessões conflitantes solicitada pelo usuário',
            ip_address=request.remote_addr
        )
        db.session.add(security_log)
        
        # Reativar automação após limpeza
        if disconnect_result:
            account.automation_active = True
            account.is_online = True
            account.last_activity = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Desconexão forçada executada com sucesso',
            'disconnect_executed': disconnect_result,
            'account': account.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro ao forçar desconexão: {str(e)}'}), 500

@account_bp.route('/accounts/<int:account_id>/security-logs', methods=['GET'])
def get_security_logs(account_id):
    """Obtém logs de segurança de uma conta"""
    try:
        from src.models.account import SecurityLog
        
        # Verificar se a conta existe
        Account.query.get_or_404(account_id)
        
        # Buscar logs de segurança
        logs = SecurityLog.query.filter_by(account_id=account_id).order_by(SecurityLog.timestamp.desc()).limit(50).all()
        
        return jsonify({
            'account_id': account_id,
            'total_logs': len(logs),
            'security_logs': [log.to_dict() for log in logs]
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar logs: {str(e)}'}), 500

@account_bp.route('/security/monitor', methods=['GET'])
def security_monitor():
    """Monitor geral de segurança do sistema"""
    try:
        from src.models.account import SecurityLog
        
        # Estatísticas gerais
        total_accounts = Account.query.filter_by(status='active').count()
        online_accounts = Account.query.filter_by(is_online=True).count()
        
        # Eventos de segurança recentes (últimas 24 horas)
        from datetime import timedelta
        yesterday = datetime.utcnow() - timedelta(days=1)
        recent_security_events = SecurityLog.query.filter(SecurityLog.timestamp >= yesterday).count()
        
        # Conflitos detectados hoje
        conflicts_today = SecurityLog.query.filter(
            SecurityLog.timestamp >= yesterday,
            SecurityLog.event_type == 'forced_disconnect'
        ).count()
        
        return jsonify({
            'system_status': {
                'total_accounts': total_accounts,
                'online_accounts': online_accounts,
                'recent_security_events': recent_security_events,
                'conflicts_detected_today': conflicts_today
            },
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro no monitor de segurança: {str(e)}'}), 500

