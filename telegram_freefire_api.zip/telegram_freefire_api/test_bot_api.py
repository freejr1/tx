#!/usr/bin/env python3
"""
Script de teste para as funcionalidades do bot Telegram
Testa a comunicação entre bot e API sem usar o Telegram real
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from telegram_bot import FreeFireBotAPI

def test_api_connection():
    """Testa conexão básica com a API"""
    print("🔍 Testando conexão com API...")
    
    # Testar endpoint de health
    try:
        import requests
        response = requests.get("http://localhost:5001/api/health", timeout=5)
        if response.status_code == 200:
            print("✅ API está online e respondendo")
            print(f"📊 Resposta: {response.json()}")
        else:
            print(f"❌ API retornou status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Erro ao conectar com API: {e}")
        return False
    
    return True

def test_add_account():
    """Testa adição de conta via bot API"""
    print("\n🎮 Testando adição de conta...")
    
    # Dados de teste
    user_id = "987654321"
    username = "bot_test_user"
    token_url = "https://reward.ff.garena.com/pt?access_token=306BF4EE4DBB9327CF90E9FAE1E37E6ADCA45761386CB82F2A871CFDA08B974F69D42638C8D05A4981D9716BB2AF9A2859CEBF2B1E38DC29AB9DAAB474DF790CFC6DB77FD0BCA8B5B9E1C205EC32BD22"
    
    result, status_code = FreeFireBotAPI.add_account(user_id, username, token_url)
    
    if status_code == 201:
        print("✅ Conta adicionada com sucesso!")
        print(f"🆔 ID da conta: {result['account']['id']}")
        print(f"📈 Nível inicial: {result['account']['current_level']}")
        return result['account']['id']
    else:
        print(f"❌ Erro ao adicionar conta: {result.get('error', 'Erro desconhecido')}")
        return None

def test_start_automation(account_id):
    """Testa início de automação"""
    print(f"\n🤖 Testando início de automação para conta {account_id}...")
    
    result, status_code = FreeFireBotAPI.start_automation(account_id, "both")
    
    if status_code == 200:
        print("✅ Automação iniciada com sucesso!")
        print(f"🔄 Tipo: {result.get('automation_type', 'N/A')}")
        print(f"⏰ Duração: {result.get('duration_hours', 'N/A')} horas")
        return True
    else:
        print(f"❌ Erro ao iniciar automação: {result.get('error', 'Erro desconhecido')}")
        return False

def test_security_check(account_id):
    """Testa verificação de segurança"""
    print(f"\n🔒 Testando verificação de segurança para conta {account_id}...")
    
    result, status_code = FreeFireBotAPI.security_check(account_id)
    
    if status_code == 200:
        security_status = result.get('security_status', {})
        conflict_detected = security_status.get('conflict_detected', False)
        
        if conflict_detected:
            print("🚨 CONFLITO DETECTADO!")
            print(f"⚠️ Ação tomada: {security_status.get('action_taken', 'N/A')}")
        else:
            print("✅ Conta segura - nenhum conflito detectado")
        
        print(f"🕐 Verificado em: {security_status.get('timestamp', 'N/A')}")
        return True
    else:
        print(f"❌ Erro na verificação de segurança: {result.get('error', 'Erro desconhecido')}")
        return False

def test_get_user_summary(user_id):
    """Testa obtenção de resumo do usuário"""
    print(f"\n📊 Testando resumo do usuário {user_id}...")
    
    result, status_code = FreeFireBotAPI.get_user_summary(user_id)
    
    if status_code == 200:
        summary = result.get('summary', {})
        print("✅ Resumo obtido com sucesso!")
        print(f"📱 Total de contas: {summary.get('total_accounts', 0)}")
        print(f"🟢 Contas online: {summary.get('online_accounts', 0)}")
        print(f"🤖 Automações ativas: {summary.get('active_automations', 0)}")
        print(f"⚡ XP total hoje: {summary.get('total_xp_today', 0)}")
        return True
    else:
        print(f"❌ Erro ao obter resumo: {result.get('error', 'Erro desconhecido')}")
        return False

def main():
    """Função principal de teste"""
    print("🎮 Bot Free Fire UP System - Teste de Funcionalidades")
    print("=" * 60)
    
    # Teste 1: Conexão com API
    if not test_api_connection():
        print("\n❌ Falha na conexão com API. Verifique se a API está rodando.")
        return
    
    # Teste 2: Adicionar conta
    account_id = test_add_account()
    if not account_id:
        print("\n❌ Falha ao adicionar conta. Parando testes.")
        return
    
    # Teste 3: Iniciar automação
    if not test_start_automation(account_id):
        print("\n❌ Falha ao iniciar automação.")
    
    # Teste 4: Verificação de segurança
    if not test_security_check(account_id):
        print("\n❌ Falha na verificação de segurança.")
    
    # Teste 5: Resumo do usuário
    if not test_get_user_summary("987654321"):
        print("\n❌ Falha ao obter resumo do usuário.")
    
    print("\n" + "=" * 60)
    print("✅ Testes concluídos!")
    print("\n💡 Para testar o bot real:")
    print("1. Inicie o bot: python telegram_bot.py")
    print("2. Abra o Telegram e procure pelo seu bot")
    print("3. Use /start para ver os comandos disponíveis")

if __name__ == "__main__":
    main()

